"""
Dataset loading utilities.

Each dataset is loaded from the local `datasets/` directory.
The function returns (X, y, feature_names, descriptions, domain_tags)
ready for use with LLMSelect and the baseline methods.

Datasets must be downloaded separately — see README.md for sources.
Kaggle datasets with placeholder TODO markers require the correct
/datasets/ slugs (see Table 2 of the manuscript).
"""

from __future__ import annotations
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd


# ── Dataset metadata ───────────────────────────────────────────────────────
# Maps dataset name to (loader_function_name, source_note)

DATASET_REGISTRY: dict[str, dict] = {
    "GeneExpress-1K": {
        "source": "NCBI GEO GSE73072",
        "file":   "GeneExpress-1K.csv",
        "label_col": "label",
    },
    "FinanceStock-2K": {
        "source": "Kaggle — see README for correct /datasets/ slug",  # TODO
        "file":   "FinanceStock-2K.csv",
        "label_col": "label",
    },
    "TextCorpus-3K": {
        "source": "Reuters-21578, UCI ML Repository",
        "file":   "TextCorpus-3K.csv",
        "label_col": "label",
    },
    "ImageFeatures-1.5K": {
        "source": "CIFAR-10 (flattened pixel features)",
        "file":   "ImageFeatures-1.5K.csv",
        "label_col": "label",
    },
    "BioMarkers-800": {
        "source": "NCBI GEO GSE19804",
        "file":   "BioMarkers-800.csv",
        "label_col": "label",
    },
    "SocialMedia-4K": {
        "source": "Kaggle — TODO: replace with correct /datasets/ slug",  # TODO
        "file":   "SocialMedia-4K.csv",
        "label_col": "label",
    },
    "MedicalImaging-2K": {
        "source": "Kaggle — TODO: replace with correct /datasets/ slug",  # TODO
        "file":   "MedicalImaging-2K.csv",
        "label_col": "label",
    },
    "CryptoMarket-1.8K": {
        "source": "CoinPaprika public API (https://api.coinpaprika.com)",
        "file":   "CryptoMarket-1.8K.csv",
        "label_col": "label",
    },
    "ProteinSeq-900": {
        "source": "UniProt Swiss-Prot curated (https://www.uniprot.org/)",
        "file":   "ProteinSeq-900.csv",
        "label_col": "label",
    },
    "DocumentClass-5K": {
        "source": "20 Newsgroups (sklearn.datasets.fetch_20newsgroups)",
        "file":   "DocumentClass-5K.csv",
        "label_col": "label",
    },
    "FaceRecog-2.5K": {
        "source": "Yale Face Database B (http://vision.ucsd.edu/~leekc/ExtYaleDatabase/)",
        "file":   "FaceRecog-2.5K.csv",
        "label_col": "label",
    },
    "ForexPred-1.2K": {
        "source": "Kaggle — TODO: replace with correct /datasets/ slug",  # TODO
        "file":   "ForexPred-1.2K.csv",
        "label_col": "label",
    },
}


def load_dataset(
    name: str,
    datasets_dir: Path | str = "datasets/",
) -> tuple[np.ndarray, np.ndarray, list[str], list[str], list[list[str]]]:
    """
    Load a benchmark dataset from disk.

    Parameters
    ----------
    name         : dataset name (key in DATASET_REGISTRY)
    datasets_dir : path to the directory containing the CSV files

    Returns
    -------
    X            : (n, p) float64 feature matrix
    y            : (n,) int64 class labels
    feature_names: list of p column names
    descriptions : list of p natural language descriptions
                   (auto-generated as ontology-aligned TF-IDF surrogates
                   where no hand-written description is available)
    domain_tags  : list of p lists of domain tag strings
    """
    if name not in DATASET_REGISTRY:
        raise ValueError(f"Unknown dataset: {name!r}.  Known: {list(DATASET_REGISTRY)}")

    meta = DATASET_REGISTRY[name]
    csv_path = Path(datasets_dir) / meta["file"]

    if not csv_path.exists():
        raise FileNotFoundError(
            f"Dataset file not found: {csv_path}\n"
            f"Source: {meta['source']}\n"
            f"Download the dataset and place it at the path above."
        )

    df = pd.read_csv(csv_path)
    label_col = meta["label_col"]
    if label_col not in df.columns:
        raise ValueError(f"Label column '{label_col}' not found in {csv_path}")

    y = df[label_col].to_numpy(dtype=np.int64)
    X = df.drop(columns=[label_col]).to_numpy(dtype=np.float64)
    feature_names = [c for c in df.columns if c != label_col]

    # Generate TF-IDF ontology-aligned descriptions as surrogates
    descriptions = _generate_descriptions(feature_names, name)
    domain_tags  = _generate_domain_tags(feature_names, name)

    return X, y, feature_names, descriptions, domain_tags


# ── Description and tag generation ────────────────────────────────────────

def _generate_descriptions(feature_names: list[str], dataset_name: str) -> list[str]:
    """
    Generate ontology-aligned TF-IDF surrogate descriptions for features
    that have no hand-written annotation available.  The description is
    used in block (i) of the GPT-4.1 prompt (Section 4.3).
    """
    domain_prefix = _domain_prefix(dataset_name)
    return [
        f"{domain_prefix} feature: {name.replace('_', ' ').replace('-', ' ')}"
        for name in feature_names
    ]


def _generate_domain_tags(feature_names: list[str], dataset_name: str) -> list[list[str]]:
    """
    Assign ontology-aligned domain tags (block iii of the GPT-4.1 prompt).
    """
    tags_map = {
        "GeneExpress":     ["genomics", "expression", "microarray"],
        "FinanceStock":    ["finance", "time-series", "equity"],
        "TextCorpus":      ["NLP", "text", "TF-IDF"],
        "ImageFeatures":   ["vision", "pixel", "image"],
        "BioMarkers":      ["biomarker", "proteomics", "clinical"],
        "SocialMedia":     ["social-media", "text", "sentiment"],
        "MedicalImaging":  ["medical-imaging", "radiology", "pixel"],
        "CryptoMarket":    ["finance", "cryptocurrency", "time-series"],
        "ProteinSeq":      ["bioinformatics", "sequence", "protein"],
        "DocumentClass":   ["NLP", "text", "document"],
        "FaceRecog":       ["vision", "face", "pixel"],
        "ForexPred":       ["finance", "forex", "time-series"],
    }
    prefix = dataset_name.split("-")[0]
    tags = tags_map.get(prefix, ["general"])
    return [list(tags) for _ in feature_names]


def _domain_prefix(dataset_name: str) -> str:
    mapping = {
        "GeneExpress":    "Gene expression",
        "FinanceStock":   "Financial",
        "TextCorpus":     "Text corpus",
        "ImageFeatures":  "Image",
        "BioMarkers":     "Biomarker",
        "SocialMedia":    "Social media",
        "MedicalImaging": "Medical imaging",
        "CryptoMarket":   "Cryptocurrency market",
        "ProteinSeq":     "Protein sequence",
        "DocumentClass":  "Document classification",
        "FaceRecog":      "Face recognition",
        "ForexPred":      "Forex",
    }
    prefix = dataset_name.split("-")[0]
    return mapping.get(prefix, "Generic")
