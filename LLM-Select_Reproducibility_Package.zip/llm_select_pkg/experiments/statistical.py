"""
Statistical comparison tests (Table S2b of the manuscript).

For each of the ten baselines, the following are computed across the twelve
benchmark datasets:

    W statistic     Wilcoxon signed-rank test (two-sided)
                    H0: LLM-Select accuracy = baseline accuracy
    p-value         Holm-Bonferroni corrected across all 10 comparisons
    Cohen's d_z     Effect size over 12 paired dataset differences

All tests use n = 12 datasets (one observation per dataset, averaged over
the five repeated seeds).  W = 78 is the maximum possible Wilcoxon W for
n = 12 (all differences positive).

Reference:
    Wilcoxon, F. (1945). Individual comparisons by ranking methods.
        Biometrics Bulletin, 1(6), 80-83.
    Holm, S. (1979). A simple sequentially rejective multiple test procedure.
        Scandinavian Journal of Statistics, 6(2), 65-70.
    Cohen, J. (1988). Statistical Power Analysis for the Behavioral Sciences
        (2nd ed.).
"""

from __future__ import annotations
import argparse
import csv
import os
from pathlib import Path

import numpy as np
from scipy import stats


# ── Core statistics ────────────────────────────────────────────────────────

def wilcoxon_two_sided(d: np.ndarray) -> tuple[float, float]:
    """
    Two-sided Wilcoxon signed-rank test.

    Parameters
    ----------
    d : (n,) array of paired differences (LLM-Select minus baseline)

    Returns
    -------
    W  : test statistic (sum of positive ranks)
    p  : two-sided p-value
    """
    result = stats.wilcoxon(d, alternative="two-sided")
    return float(result.statistic), float(result.pvalue)


def cohens_dz(d: np.ndarray) -> float:
    """
    Cohen's d_z = mean(d) / std(d, ddof=1).

    Measures the standardised effect size over n paired observations.
    Classified as: small |d_z| >= 0.2, medium >= 0.5, large >= 0.8
    (Cohen, 1988).
    """
    if d.std(ddof=1) == 0:
        return float("inf")
    return float(d.mean() / d.std(ddof=1))


def holm_bonferroni(pvalues: list[float]) -> list[float]:
    """
    Holm-Bonferroni step-down correction.

    Parameters
    ----------
    pvalues : list of m raw p-values

    Returns
    -------
    corrected : list of corrected p-values (same order as input)
    """
    m = len(pvalues)
    order = np.argsort(pvalues)
    corrected = np.zeros(m)
    running_max = 0.0
    for rank, idx in enumerate(order):
        adjusted = pvalues[idx] * (m - rank)
        running_max = max(running_max, adjusted)
        corrected[idx] = min(running_max, 1.0)
    return corrected.tolist()


# ── Main comparison table ──────────────────────────────────────────────────

def compute_comparison_table(
    llm_select_accs: np.ndarray,
    baseline_accs: dict[str, np.ndarray],
) -> list[dict]:
    """
    Build Table S2b.

    Parameters
    ----------
    llm_select_accs : (12,) array of LLM-Select mean accuracy per dataset
    baseline_accs   : {baseline_name: (12,) accuracy array}

    Returns
    -------
    rows : list of dicts with keys
           baseline, W, p_raw, p_corrected, cohens_dz, interpretation
    """
    baseline_names = list(baseline_accs.keys())
    raw_pvalues = []
    W_stats = []
    dz_vals = []

    for name in baseline_names:
        d = llm_select_accs - baseline_accs[name]
        W, p = wilcoxon_two_sided(d)
        dz = cohens_dz(d)
        W_stats.append(W)
        raw_pvalues.append(p)
        dz_vals.append(dz)

    corrected = holm_bonferroni(raw_pvalues)

    rows = []
    for i, name in enumerate(baseline_names):
        dz = dz_vals[i]
        if abs(dz) >= 0.8:
            interp = "Large"
        elif abs(dz) >= 0.5:
            interp = "Medium"
        else:
            interp = "Small"
        rows.append({
            "baseline":      name,
            "W":             W_stats[i],
            "p_raw":         raw_pvalues[i],
            "p_corrected":   corrected[i],
            "cohens_dz":     round(dz, 2),
            "interpretation": interp,
        })
    return rows


def print_table(rows: list[dict]) -> None:
    header = f"{'Baseline':<18} {'W':>6} {'p (raw)':>12} {'p (Holm)':>12} {'d_z':>8} {'Interpretation'}"
    print(header)
    print("-" * len(header))
    for r in rows:
        print(
            f"{r['baseline']:<18} {r['W']:>6.0f} {r['p_raw']:>12.6f} "
            f"{r['p_corrected']:>12.6f} {r['cohens_dz']:>8.2f}  {r['interpretation']}"
        )


# ── CLI ────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute Table S2b from saved experiment results."
    )
    parser.add_argument("--results", required=True, help="Directory with results CSV files")
    parser.add_argument("--output", default="results/table_s2b.csv")
    args = parser.parse_args()

    results_dir = Path(args.results)
    # Expect files: {method}_accs.npy  shape (12,)
    llm_accs = np.load(results_dir / "LLM-Select_accs.npy")
    baselines = [
        "CAAFE", "mRMR", "ReliefF", "Boruta", "SHAP-Select",
        "Random Forest", "Lasso", "CFS", "FCBF", "Chi-Square",
    ]
    baseline_accs = {
        b: np.load(results_dir / f"{b.replace(' ', '_')}_accs.npy")
        for b in baselines
    }

    rows = compute_comparison_table(llm_accs, baseline_accs)
    print_table(rows)

    os.makedirs(Path(args.output).parent, exist_ok=True)
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nSaved to {args.output}")


if __name__ == "__main__":
    main()
