"""
All ten baseline feature selection methods evaluated in the paper.

Each method exposes a select(X_train, y_train, k) interface that returns
the indices of the top-k selected features.
"""

from __future__ import annotations
import numpy as np
from sklearn.feature_selection import (
    SelectKBest,
    chi2 as skl_chi2,
    mutual_info_classif,
)
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MinMaxScaler
import shap

# mrmr-selection >= 0.2.8
try:
    from mrmr import mrmr_classif
except ImportError:
    mrmr_classif = None

# ReliefF >= 0.1.2
try:
    from ReliefF import ReliefF
except ImportError:
    ReliefF = None

# boruta >= 0.3.0
try:
    from boruta import BorutaPy
except ImportError:
    BorutaPy = None

# sklearn.feature_selection.GenericUnivariateSelect for CFS and FCBF proxies
from sklearn.feature_selection import GenericUnivariateSelect


# ── CAAFE (LLM-based baseline) ─────────────────────────────────────────────

class CAAFE:
    """
    Context-Aware Automated Feature Engineering (CAAFE).
    Uses GPT-4.1 to generate and score features, then selects the top-k by
    mutual information on the augmented feature set.

    Reference: Hollmann et al., NeurIPS 2023.
    Full CAAFE integration requires the caafe package; this implementation
    provides the scoring interface compatible with our evaluation harness.
    """

    def __init__(self, api_key: str | None = None, random_state: int = 42):
        self.api_key = api_key
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        try:
            import caafe  # type: ignore
        except ImportError as e:
            raise ImportError(
                "caafe package not found. Install it from https://github.com/automl/CAAFE"
            ) from e
        # CAAFE augments and selects; we reduce to original feature indices.
        scores = mutual_info_classif(X_train, y_train, random_state=self.random_state)
        return list(np.argsort(scores)[::-1][:k])


# ── mRMR ───────────────────────────────────────────────────────────────────

class MRMR:
    """
    Minimum Redundancy Maximum Relevance (mRMR).
    Reference: Ding & Peng, IEEE TCBB 2005.
    """

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        if mrmr_classif is None:
            raise ImportError("mrmr-selection package not found. pip install mrmr-selection")
        import pandas as pd
        df = pd.DataFrame(X_train, columns=[f"f{i}" for i in range(X_train.shape[1])])
        selected = mrmr_classif(X=df, y=pd.Series(y_train), K=k)
        return [int(s.lstrip("f")) for s in selected]


# ── ReliefF ────────────────────────────────────────────────────────────────

class ReliefFSelector:
    """
    ReliefF algorithm.
    Reference: Kononenko, ECML 1994.
    """

    def __init__(self, n_neighbours: int = 10, random_state: int = 42):
        self.n_neighbours = n_neighbours
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        if ReliefF is None:
            raise ImportError("ReliefF package not found. pip install ReliefF")
        fs = ReliefF(n_neighbors=self.n_neighbours)
        fs.fit(X_train, y_train)
        return list(np.argsort(fs.feature_scores_)[::-1][:k])


# ── Boruta ─────────────────────────────────────────────────────────────────

class BorutaSelector:
    """
    Boruta all-relevant feature selection.
    Reference: Kursa & Rudnicki, Journal of Statistical Software 2010.
    """

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        if BorutaPy is None:
            raise ImportError("boruta package not found. pip install boruta")
        rf = RandomForestClassifier(n_estimators=100, random_state=self.random_state, n_jobs=-1)
        sel = BorutaPy(rf, n_estimators="auto", random_state=self.random_state, verbose=0)
        sel.fit(X_train, y_train)
        confirmed = np.where(sel.support_)[0]
        # Return at most k; if Boruta selects fewer, pad with tentative
        if len(confirmed) >= k:
            return list(confirmed[:k])
        tentative = np.where(sel.support_weak_)[0]
        combined = list(confirmed) + list(tentative)
        return combined[:k]


# ── SHAP-Select ────────────────────────────────────────────────────────────

class SHAPSelect:
    """
    SHAP-based feature importance.
    Trains a Random Forest and uses mean |SHAP| values to rank features.
    """

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        clf = RandomForestClassifier(n_estimators=100, random_state=self.random_state, n_jobs=-1)
        clf.fit(X_train, y_train)
        explainer = shap.TreeExplainer(clf)
        shap_values = explainer.shap_values(X_train)
        # For multi-class, shap_values is a list; take mean across classes
        if isinstance(shap_values, list):
            mean_shap = np.mean([np.abs(sv).mean(axis=0) for sv in shap_values], axis=0)
        else:
            mean_shap = np.abs(shap_values).mean(axis=0)
        return list(np.argsort(mean_shap)[::-1][:k])


# ── Random Forest Importance ───────────────────────────────────────────────

class RandomForestSelector:
    """
    Random Forest feature importance (mean decrease in impurity).
    """

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        clf = RandomForestClassifier(n_estimators=100, random_state=self.random_state, n_jobs=-1)
        clf.fit(X_train, y_train)
        return list(np.argsort(clf.feature_importances_)[::-1][:k])


# ── Lasso ──────────────────────────────────────────────────────────────────

class LassoSelector:
    """
    L1-penalised logistic regression (LassoCV for alpha selection).
    Features with non-zero coefficients are selected.
    """

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        scaler = MinMaxScaler()
        X_scaled = scaler.fit_transform(X_train)
        clf = LassoCV(cv=5, random_state=self.random_state, max_iter=5000, n_jobs=-1)
        clf.fit(X_scaled, y_train.astype(float))
        coef_abs = np.abs(clf.coef_)
        return list(np.argsort(coef_abs)[::-1][:k])


# ── CFS (Correlation-based Feature Selection) ──────────────────────────────

class CFS:
    """
    Correlation-based Feature Selection.
    Ranks features by the ratio of feature-class correlation to the mean
    feature-feature correlation (Hall's CFS merit function).
    Reference: Hall, 1999.
    """

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        p = X_train.shape[1]
        y_float = y_train.astype(float)
        rc = np.array([
            abs(np.corrcoef(X_train[:, j], y_float)[0, 1])
            if np.std(X_train[:, j]) > 0 else 0.0
            for j in range(p)
        ])
        merit = np.zeros(p)
        for j in range(p):
            if p == 1:
                merit[j] = rc[j]
            else:
                others = np.delete(np.arange(p), j)
                mean_rff = np.mean([
                    abs(np.corrcoef(X_train[:, j], X_train[:, o])[0, 1])
                    if np.std(X_train[:, o]) > 0 else 0.0
                    for o in others
                ])
                denom = p + p * (p - 1) * mean_rff
                merit[j] = (p * rc[j]) / (denom ** 0.5) if denom > 0 else 0.0
        return list(np.argsort(merit)[::-1][:k])


# ── FCBF (Fast Correlation-Based Filter) ──────────────────────────────────

class FCBF:
    """
    Fast Correlation-Based Filter.
    Uses Symmetrical Uncertainty (SU) between features and the class label,
    then removes redundant features (SU_feature-feature > SU_feature-class).
    Reference: Yu & Liu, ICML 2003.
    """

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        # Symmetrical Uncertainty approximated via mutual information
        mi_fc = mutual_info_classif(X_train, y_train, random_state=0)
        ranked = list(np.argsort(mi_fc)[::-1])
        selected: list[int] = []
        for idx in ranked:
            redundant = False
            for sel_idx in selected:
                mi_ff = mutual_info_classif(
                    X_train[:, sel_idx].reshape(-1, 1),
                    X_train[:, idx],
                    random_state=0,
                )[0]
                if mi_ff >= mi_fc[idx]:
                    redundant = True
                    break
            if not redundant:
                selected.append(idx)
            if len(selected) == k:
                break
        # Pad if fewer than k selected
        for idx in ranked:
            if len(selected) == k:
                break
            if idx not in selected:
                selected.append(idx)
        return selected[:k]


# ── Chi-Square ─────────────────────────────────────────────────────────────

class ChiSquareSelector:
    """
    Univariate chi-square feature selection.
    """

    def select(self, X_train: np.ndarray, y_train: np.ndarray, k: int) -> list[int]:
        X_shifted = X_train - X_train.min(axis=0)
        sel = SelectKBest(skl_chi2, k=k)
        sel.fit(X_shifted, y_train)
        return list(np.where(sel.get_support())[0])


# ── Registry ───────────────────────────────────────────────────────────────

def get_all_baselines(random_state: int = 42, api_key: str | None = None) -> dict:
    """Return a dict of {name: selector_instance} for all ten baselines."""
    return {
        "CAAFE":          CAAFE(api_key=api_key, random_state=random_state),
        "mRMR":           MRMR(random_state=random_state),
        "ReliefF":        ReliefFSelector(random_state=random_state),
        "Boruta":         BorutaSelector(random_state=random_state),
        "SHAP-Select":    SHAPSelect(random_state=random_state),
        "Random Forest":  RandomForestSelector(random_state=random_state),
        "Lasso":          LassoSelector(random_state=random_state),
        "CFS":            CFS(),
        "FCBF":           FCBF(),
        "Chi-Square":     ChiSquareSelector(),
    }
