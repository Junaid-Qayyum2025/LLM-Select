"""Shared utilities."""
from __future__ import annotations
import numpy as np
from sklearn.preprocessing import MinMaxScaler


def minmax_norm(arr: np.ndarray) -> np.ndarray:
    """Min-max normalise a 1D array to [0, 1]. Returns zeros if range is zero."""
    lo, hi = arr.min(), arr.max()
    if hi == lo:
        return np.zeros_like(arr, dtype=float)
    return (arr - lo) / (hi - lo)
