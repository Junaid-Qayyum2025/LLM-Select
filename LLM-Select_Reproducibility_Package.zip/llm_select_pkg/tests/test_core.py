"""
Unit tests for the LLM-Select core algorithm.

These tests use mock semantic scores so they run without an OpenAI API key.
They verify the unified score formula, redundancy penalty, k selection,
and baseline method interfaces.
"""

from __future__ import annotations
import numpy as np
import pytest
from unittest.mock import patch

from experiments.config import ALPHA, BETA, GAMMA
from llm_select.redundancy import compute_redundancy_penalty
from llm_select.traditional import aggregate_traditional_score
from experiments.statistical import (
    cohens_dz,
    holm_bonferroni,
    wilcoxon_two_sided,
)


# ── Unified score formula ──────────────────────────────────────────────────

def test_weights_sum_to_one():
    assert abs(ALPHA + BETA + GAMMA - 1.0) < 1e-9


def test_unified_score_formula():
    S = np.array([0.9, 0.5, 0.3])
    T = np.array([0.8, 0.6, 0.4])
    R = np.array([0.0, 0.2, 0.5])
    I = ALPHA * S + BETA * T - GAMMA * R
    expected = 0.48 * S + 0.39 * T - 0.13 * R
    np.testing.assert_allclose(I, expected, rtol=1e-9)


# ── Redundancy penalty ─────────────────────────────────────────────────────

def test_redundancy_empty_selected():
    X = np.random.default_rng(42).random((50, 10))
    r = compute_redundancy_penalty(X, [], 0)
    assert r == 0.0


def test_redundancy_identical_feature():
    X = np.zeros((50, 3))
    X[:, 0] = np.arange(50)
    X[:, 1] = np.arange(50)  # identical to column 0
    X[:, 2] = np.random.default_rng(0).random(50)
    r = compute_redundancy_penalty(X, [0], 1)
    assert abs(r - 1.0) < 1e-9


def test_redundancy_independent_feature():
    rng = np.random.default_rng(42)
    X = rng.random((200, 3))
    r = compute_redundancy_penalty(X, [0, 1], 2)
    assert 0.0 <= r <= 1.0


# ── Traditional score ──────────────────────────────────────────────────────

def test_traditional_score_range():
    rng = np.random.default_rng(0)
    mi = rng.random(20)
    pearson = rng.random(20)
    chi2 = rng.random(20)
    var = rng.random(20)
    T = aggregate_traditional_score(mi, pearson, chi2, var)
    assert T.min() >= 0.0
    assert T.max() <= 1.0


# ── Statistical tests ──────────────────────────────────────────────────────

def test_wilcoxon_all_positive_n12():
    """W = 78 (max) when all 12 differences are positive."""
    d = np.ones(12)
    W, p = wilcoxon_two_sided(d)
    assert W == 78.0
    assert p < 0.01


def test_cohens_dz_large():
    """d_z should be large (> 0.8) for a consistent positive effect."""
    d = np.full(12, 2.0)
    dz = cohens_dz(d)
    assert dz == float("inf")  # std = 0 → inf


def test_cohens_dz_nonzero_std():
    rng = np.random.default_rng(1)
    d = rng.normal(5, 1, size=12)
    dz = cohens_dz(d)
    assert dz > 0.8  # clearly large


def test_holm_bonferroni_monotone():
    pvalues = [0.001, 0.01, 0.05, 0.1, 0.5]
    corrected = holm_bonferroni(pvalues)
    assert corrected == sorted(corrected)


def test_holm_bonferroni_cap_at_one():
    pvalues = [0.9, 0.95, 0.99]
    corrected = holm_bonferroni(pvalues)
    assert all(p <= 1.0 for p in corrected)


# ── Baseline interface ─────────────────────────────────────────────────────

def test_chi_square_returns_k_indices():
    from baselines.methods import ChiSquareSelector
    rng = np.random.default_rng(7)
    X = rng.random((100, 20)) + 1.0  # positive values
    y = rng.integers(0, 2, size=100)
    sel = ChiSquareSelector()
    indices = sel.select(X, y, k=5)
    assert len(indices) == 5
    assert all(0 <= i < 20 for i in indices)


def test_rf_selector_returns_k_indices():
    from baselines.methods import RandomForestSelector
    rng = np.random.default_rng(3)
    X = rng.random((80, 30))
    y = rng.integers(0, 3, size=80)
    sel = RandomForestSelector(random_state=42)
    indices = sel.select(X, y, k=8)
    assert len(indices) == 8
    assert len(set(indices)) == 8  # no duplicates
