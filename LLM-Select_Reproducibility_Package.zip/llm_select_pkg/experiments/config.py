"""
LLM-Select hyperparameters.
All values match Table 6 of the manuscript exactly.
"""

# ── Combination weights (Bayesian-optimised, Table 6) ─────────────────────
ALPHA = 0.48   # semantic score weight S(f_i)
BETA  = 0.39   # traditional score weight T(f_i)
GAMMA = 0.13   # redundancy penalty weight R(f_i)
assert abs(ALPHA + BETA + GAMMA - 1.0) < 1e-9, "Weights must sum to 1."

# ── GPT-4.1 query settings ────────────────────────────────────────────────
TEMPERATURE   = 0.1    # sampling temperature
MAX_TOKENS    = 512    # maximum output tokens per API call
CONTEXT_LIMIT = 4096   # maximum context window (tokens)
BATCH_SIZE    = 50     # features per API request

# ── Optimisation ──────────────────────────────────────────────────────────
N_ITER = 15            # maximum Bayesian refinement iterations
ZETA   = 0.001         # L2 regularisation coefficient
DELTA  = 0.005         # perturbation step size

# ── Experiment protocol ───────────────────────────────────────────────────
RANDOM_SEEDS  = [42, 43, 44, 45, 46]   # five repeated runs
CV_FOLDS      = 5                       # cross-validation folds for k selection
GPT_MODEL     = "gpt-4.1"

# ── Dataset names (must match filenames in datasets/) ─────────────────────
DATASETS = [
    "GeneExpress-1K",
    "FinanceStock-2K",
    "TextCorpus-3K",
    "ImageFeatures-1.5K",
    "BioMarkers-800",
    "SocialMedia-4K",
    "MedicalImaging-2K",
    "CryptoMarket-1.8K",
    "ProteinSeq-900",
    "DocumentClass-5K",
    "FaceRecog-2.5K",
    "ForexPred-1.2K",
]
