"""
GPT-4.1 semantic importance scoring (Section 4.3 of the manuscript).

Each feature is scored by sending a four-block prompt to the GPT-4.1 API
and parsing the returned 0.0–1.0 numeric value.  Requests are batched in
groups of BATCH_SIZE features to stay within the context window.
"""

from __future__ import annotations
import math
import os
import time
from typing import Sequence

import numpy as np
import openai

from experiments.config import (
    BATCH_SIZE,
    CONTEXT_LIMIT,
    GPT_MODEL,
    MAX_TOKENS,
    TEMPERATURE,
)


# ── Prompt construction ────────────────────────────────────────────────────

def _build_prompt(
    feature_name: str,
    description: str,
    mutual_info: float,
    pearson_r: float,
    chi2_stat: float,
    variance: float,
    domain_tags: list[str],
) -> str:
    """
    Construct the four-block prompt described in Section 4.3 and Table S1-1.

    Block (i)   Feature Description — natural language description or
                ontology-aligned TF-IDF surrogate where none is available.
    Block (ii)  Statistical Summary — normalised MI, Pearson r, chi-square,
                and variance (four decimal places; label-dependent statistics
                computed on training fold only).
    Block (iii) Domain Tags — ontology-aligned labels from Section 4.5.
    Block (iv)  Ranking Instruction.

    NOTE: MI, Pearson r, and chi-square are label-dependent statistics.
    Although class labels are not provided directly, block (ii) is an
    indirect channel of label information; the semantic score is therefore
    not strictly label-free (see Section 6, Limitations).
    """
    stats = (
        f"Mutual information (normalised): {mutual_info:.4f}\n"
        f"Pearson correlation (abs):       {pearson_r:.4f}\n"
        f"Chi-square statistic (normalised): {chi2_stat:.4f}\n"
        f"Variance (normalised):           {variance:.4f}"
    )
    tags = ", ".join(domain_tags) if domain_tags else "none"
    return (
        f"Feature name: {feature_name}\n\n"
        f"[Feature Description]\n{description}\n\n"
        f"[Statistical Summary]\n{stats}\n\n"
        f"[Domain Tags]\n{tags}\n\n"
        "[Ranking Instruction]\n"
        "Rate the predictive relevance of this feature for the classification "
        "task on a scale from 0.0 to 1.0. Return only the numeric value, "
        "with no additional text."
    )


# ── API call with retry ────────────────────────────────────────────────────

def _call_gpt(prompt: str, client: openai.OpenAI, retries: int = 5) -> float:
    """
    Call the GPT-4.1 API and parse the single numeric response.
    Returns NaN on persistent failure (the caller handles imputation).
    """
    for attempt in range(retries):
        try:
            response = client.chat.completions.create(
                model=GPT_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=TEMPERATURE,
                max_tokens=MAX_TOKENS,
            )
            text = response.choices[0].message.content.strip()
            return float(text)
        except (ValueError, IndexError):
            # Response did not contain a parseable float; treat as NaN
            return float("nan")
        except openai.RateLimitError:
            wait = 2 ** attempt
            time.sleep(wait)
        except openai.APIError as exc:
            if attempt == retries - 1:
                raise
            time.sleep(2 ** attempt)
    return float("nan")


# ── Batch scoring ──────────────────────────────────────────────────────────

def compute_semantic_scores(
    feature_names: Sequence[str],
    descriptions: Sequence[str],
    mutual_info: np.ndarray,
    pearson_r: np.ndarray,
    chi2: np.ndarray,
    variance: np.ndarray,
    domain_tags: Sequence[list[str]],
    api_key: str | None = None,
) -> np.ndarray:
    """
    Compute S(f_i) for every feature using GPT-4.1.

    Parameters
    ----------
    feature_names : sequence of str, length p
    descriptions  : sequence of str, length p
        Natural language description of each feature, or ontology-aligned
        TF-IDF surrogate.  Must not be empty strings.
    mutual_info   : (p,) array, normalised to [0, 1]
    pearson_r     : (p,) array, abs value, normalised to [0, 1]
    chi2          : (p,) array, normalised to [0, 1]
    variance      : (p,) array, normalised to [0, 1]
    domain_tags   : sequence of lists, length p
    api_key       : OpenAI API key (falls back to OPENAI_API_KEY env var)

    Returns
    -------
    scores : (p,) float array in [0, 1].  NaN entries (failed calls) are
             imputed with the median of all successful scores.
    """
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise EnvironmentError(
            "OpenAI API key not found.  Set OPENAI_API_KEY or pass api_key."
        )
    client = openai.OpenAI(api_key=key)

    p = len(feature_names)
    scores = np.full(p, float("nan"))
    n_batches = math.ceil(p / BATCH_SIZE)

    for b in range(n_batches):
        lo = b * BATCH_SIZE
        hi = min(lo + BATCH_SIZE, p)
        for i in range(lo, hi):
            prompt = _build_prompt(
                feature_name=feature_names[i],
                description=descriptions[i],
                mutual_info=float(mutual_info[i]),
                pearson_r=float(pearson_r[i]),
                chi2_stat=float(chi2[i]),
                variance=float(variance[i]),
                domain_tags=domain_tags[i],
            )
            scores[i] = _call_gpt(prompt, client)

    # Impute NaN with median of successful scores
    valid = scores[~np.isnan(scores)]
    if valid.size > 0:
        scores = np.where(np.isnan(scores), np.median(valid), scores)
    else:
        scores = np.zeros(p)

    # Clip to [0, 1] in case of out-of-range responses
    return np.clip(scores, 0.0, 1.0)
