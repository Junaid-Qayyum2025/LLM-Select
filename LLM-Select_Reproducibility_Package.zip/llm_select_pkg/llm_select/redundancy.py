"""
Pairwise redundancy penalty R(f_i) (Section 4.4 of the manuscript).

R(f_i) penalises features that are highly correlated with features already
ranked above them in the current ordering.  A higher R(f_i) means greater
redundancy, so the unified score subtracts gamma * R(f_i).
"""

from __future__ import annotations
import numpy as np


def compute_redundancy_penalty(
    X: np.ndarray,
    selected_indices: list[int],
    candidate_idx: int,
) -> float:
    """
    R(f_candidate) = mean absolute Pearson correlation between the candidate
    feature and all features already in the selected set.

    Returns 0.0 when selected_indices is empty (no penalty for the first
    feature selected).

    Parameters
    ----------
    X                : (n, p) feature matrix (training fold)
    selected_indices : indices of features already selected
    candidate_idx    : index of the candidate feature

    Returns
    -------
    float in [0, 1]
    """
    if not selected_indices:
        return 0.0

    candidate = X[:, candidate_idx]
    if np.std(candidate) == 0:
        return 0.0

    correlations = []
    for idx in selected_indices:
        other = X[:, idx]
        if np.std(other) == 0:
            correlations.append(0.0)
        else:
            r = np.corrcoef(candidate, other)[0, 1]
            correlations.append(abs(r))

    return float(np.mean(correlations))


def compute_all_redundancy_penalties(
    X: np.ndarray,
    current_selected: list[int],
    candidate_pool: list[int],
) -> np.ndarray:
    """
    Vectorised redundancy penalties for all candidates in candidate_pool.

    Parameters
    ----------
    X                : (n, p) feature matrix
    current_selected : indices already chosen in this selection step
    candidate_pool   : indices to evaluate

    Returns
    -------
    (len(candidate_pool),) array of R values in [0, 1]
    """
    penalties = np.array([
        compute_redundancy_penalty(X, current_selected, idx)
        for idx in candidate_pool
    ])
    return penalties
