"""
Traditional importance score T(f_i) (Section 4.4 of the manuscript).

T(f_i) is a normalised aggregate of mutual information, absolute Pearson
correlation, chi-square statistic, and variance.  All four statistics are
normalised to [0, 1] by min-max scaling across the feature set, then
averaged with equal weights.
"""

from __future__ import annotations
import numpy as np
from sklearn.feature_selection import mutual_info_classif, chi2
from sklearn.preprocessing import MinMaxScaler


def compute_traditional_scores(
    X_train: np.ndarray,
    y_train: np.ndarray,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute the four component statistics used in T(f_i) and in the
    four-block GPT-4.1 prompt.

    Parameters
    ----------
    X_train      : (n, p) training feature matrix
    y_train      : (n,) integer class labels
    random_state : passed to mutual_info_classif for reproducibility

    Returns
    -------
    mi_norm    : (p,) normalised mutual information in [0, 1]
    pearson_norm : (p,) normalised |Pearson r| in [0, 1]
    chi2_norm  : (p,) normalised chi-square statistic in [0, 1]
    var_norm   : (p,) normalised variance in [0, 1]

    NOTE: MI, Pearson r, and chi-square are label-dependent and are
    computed on training data only to prevent data leakage.
    """
    scaler = MinMaxScaler()

    # Mutual information
    mi = mutual_info_classif(X_train, y_train, random_state=random_state)
    mi_norm = scaler.fit_transform(mi.reshape(-1, 1)).ravel()

    # Absolute Pearson correlation with class label
    y_float = y_train.astype(float)
    pearson = np.array([
        abs(np.corrcoef(X_train[:, j], y_float)[0, 1])
        if np.std(X_train[:, j]) > 0 else 0.0
        for j in range(X_train.shape[1])
    ])
    pearson_norm = scaler.fit_transform(pearson.reshape(-1, 1)).ravel()

    # Chi-square (requires non-negative features; shift if needed)
    X_shifted = X_train - X_train.min(axis=0)
    chi2_vals, _ = chi2(X_shifted, y_train)
    chi2_norm = scaler.fit_transform(chi2_vals.reshape(-1, 1)).ravel()

    # Variance (label-independent)
    var = X_train.var(axis=0)
    var_norm = scaler.fit_transform(var.reshape(-1, 1)).ravel()

    return mi_norm, pearson_norm, chi2_norm, var_norm


def aggregate_traditional_score(
    mi_norm: np.ndarray,
    pearson_norm: np.ndarray,
    chi2_norm: np.ndarray,
    var_norm: np.ndarray,
) -> np.ndarray:
    """
    T(f_i) = mean(MI_norm, |Pearson|_norm, chi2_norm, var_norm).
    Equal weights across the four components, normalised to [0, 1].
    """
    T = (mi_norm + pearson_norm + chi2_norm + var_norm) / 4.0
    return np.clip(T, 0.0, 1.0)
