"""
Reproduce Tables 3–17 of the manuscript.

Usage:
    python experiments/run_all.py --seeds 5 --output results/
    python experiments/run_all.py --dataset GeneExpress-1K --seeds 1 --output results/quick/
"""

from __future__ import annotations
import argparse
import os
import json
import time
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import MinMaxScaler

from experiments.config import DATASETS, RANDOM_SEEDS, CV_FOLDS
from baselines.methods import get_all_baselines
from data.loaders import load_dataset
from llm_select.core import LLMSelect


# ── Evaluation helper ──────────────────────────────────────────────────────

def evaluate(X_train, y_train, X_test, y_test, selected_indices, random_state):
    """Train a Random Forest on the selected features and return test accuracy."""
    clf = RandomForestClassifier(
        n_estimators=100, random_state=random_state, n_jobs=-1
    )
    clf.fit(X_train[:, selected_indices], y_train)
    preds = clf.predict(X_test[:, selected_indices])
    return float((preds == y_test).mean() * 100)


# ── Main loop ──────────────────────────────────────────────────────────────

def run(
    dataset_names: list[str],
    seeds: list[int],
    output_dir: Path,
    api_key: str | None,
    datasets_dir: Path,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    method_names = ["LLM-Select"] + list(get_all_baselines(random_state=42, api_key=api_key).keys())

    # acc[method][dataset] = list of accuracies across seeds
    all_results: dict[str, dict[str, list[float]]] = {
        m: {d: [] for d in dataset_names} for m in method_names
    }

    for dataset_name in dataset_names:
        print(f"\n{'='*60}")
        print(f"Dataset: {dataset_name}")
        print(f"{'='*60}")

        X, y, feature_names, descriptions, domain_tags = load_dataset(
            dataset_name, datasets_dir
        )

        for seed in seeds:
            print(f"  Seed {seed}...")
            rng = np.random.RandomState(seed)

            # Single train/test split (80/20, stratified)
            from sklearn.model_selection import train_test_split
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=seed, stratify=y
            )

            # ── LLM-Select ──────────────────────────────────────────────
            t0 = time.time()
            selector = LLMSelect(random_state=seed, api_key=api_key)
            selector.fit(X_train, y_train, feature_names, descriptions, domain_tags)
            acc = evaluate(
                X_train, y_train, X_test, y_test,
                selector.selected_indices_, seed
            )
            all_results["LLM-Select"][dataset_name].append(acc)
            k_selected = len(selector.selected_indices_)
            print(f"    LLM-Select: {acc:.1f}% (k={k_selected}, {time.time()-t0:.1f}s)")

            # ── Baselines ───────────────────────────────────────────────
            baselines = get_all_baselines(random_state=seed, api_key=api_key)
            for method_name, baseline in baselines.items():
                try:
                    indices = baseline.select(X_train, y_train, k=k_selected)
                    acc_b = evaluate(X_train, y_train, X_test, y_test, indices, seed)
                except Exception as exc:
                    print(f"    {method_name}: ERROR — {exc}")
                    acc_b = float("nan")
                all_results[method_name][dataset_name].append(acc_b)
                print(f"    {method_name}: {acc_b:.1f}%")

    # ── Save raw results ───────────────────────────────────────────────────
    with open(output_dir / "raw_results.json", "w") as f:
        json.dump(all_results, f, indent=2)

    # ── Compute per-dataset mean accuracy (averaged over seeds) ───────────
    summary: dict[str, dict[str, float]] = {}
    for method in method_names:
        summary[method] = {}
        for dataset in dataset_names:
            vals = [v for v in all_results[method][dataset] if not np.isnan(v)]
            summary[method][dataset] = float(np.mean(vals)) if vals else float("nan")

    # Save per-method numpy arrays for statistical.py
    for method in method_names:
        arr = np.array([summary[method][d] for d in dataset_names])
        fname = method.replace(" ", "_") + "_accs.npy"
        np.save(output_dir / fname, arr)

    # ── Print summary table (Table S2 format) ─────────────────────────────
    print("\n\nSummary — Mean Accuracy (%) per Dataset")
    header = f"{'Dataset':<22}" + "".join(f"{m[:10]:>12}" for m in method_names)
    print(header)
    print("-" * len(header))
    for dataset in dataset_names:
        row = f"{dataset:<22}"
        for method in method_names:
            row += f"{summary[method][dataset]:>12.1f}"
        print(row)

    print("\nMean across datasets:")
    row = f"{'Mean':22}"
    for method in method_names:
        vals = [summary[method][d] for d in dataset_names if not np.isnan(summary[method][d])]
        row += f"{np.mean(vals):>12.1f}"
    print(row)

    print(f"\nResults saved to {output_dir}")


# ── CLI ────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=None, help="Single dataset name (default: all 12)")
    parser.add_argument("--seeds", type=int, default=5, help="Number of seeds (uses first N from config)")
    parser.add_argument("--output", default="results/", help="Output directory")
    parser.add_argument("--datasets-dir", default="datasets/", help="Path to downloaded datasets")
    args = parser.parse_args()

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "OPENAI_API_KEY environment variable not set.  "
            "Export it before running: export OPENAI_API_KEY=sk-..."
        )

    dataset_names = [args.dataset] if args.dataset else DATASETS
    seeds = RANDOM_SEEDS[:args.seeds]

    run(
        dataset_names=dataset_names,
        seeds=seeds,
        output_dir=Path(args.output),
        api_key=api_key,
        datasets_dir=Path(args.datasets_dir),
    )


if __name__ == "__main__":
    main()
