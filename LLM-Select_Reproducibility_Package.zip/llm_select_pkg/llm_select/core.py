"""
LLM-Select core algorithm (Algorithm 1 of the manuscript).

Unified importance score:
    I(f_i) = alpha * S(f_i) + beta * T(f_i) - gamma * R(f_i)

where
    S(f_i)  semantic score from GPT-4.1          (weight alpha = 0.48)
    T(f_i)  traditional importance score          (weight beta  = 0.39)
    R(f_i)  pairwise redundancy penalty           (weight gamma = 0.13)

The top-k features (k tuned via cross-validation) are returned as the
selected subset.  Bayesian weight optimisation is performed over N_iter
iterations using L2-regularised log-likelihood on a held-out validation fold.
"""

from __future__ import annotations
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import MinMaxScaler

from experiments.config import (
    ALPHA, BETA, GAMMA,
    CV_FOLDS, N_ITER, ZETA, DELTA,
)
from llm_select.semantic import compute_semantic_scores
from llm_select.traditional import (
    aggregate_traditional_score,
    compute_traditional_scores,
)
from llm_select.redundancy import compute_all_redundancy_penalties


class LLMSelect:
    """
    LLM-Select feature selector.

    Parameters
    ----------
    alpha, beta, gamma : combination weights (must sum to 1.0)
    n_iter             : Bayesian refinement iterations
    zeta               : L2 regularisation coefficient
    delta              : perturbation step size for weight updates
    cv_folds           : folds for k selection via cross-validation
    random_state       : random seed for reproducibility
    api_key            : OpenAI API key (falls back to env var)
    """

    def __init__(
        self,
        alpha: float = ALPHA,
        beta: float = BETA,
        gamma: float = GAMMA,
        n_iter: int = N_ITER,
        zeta: float = ZETA,
        delta: float = DELTA,
        cv_folds: int = CV_FOLDS,
        random_state: int = 42,
        api_key: str | None = None,
    ):
        assert abs(alpha + beta + gamma - 1.0) < 1e-9
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.n_iter = n_iter
        self.zeta = zeta
        self.delta = delta
        self.cv_folds = cv_folds
        self.random_state = random_state
        self.api_key = api_key

        self.selected_indices_: list[int] | None = None
        self.scores_: np.ndarray | None = None

    # ── Public API ─────────────────────────────────────────────────────────

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        feature_names: list[str],
        descriptions: list[str],
        domain_tags: list[list[str]],
    ) -> "LLMSelect":
        """
        Run the full LLM-Select pipeline on the training fold.

        Parameters
        ----------
        X_train       : (n, p) training feature matrix
        y_train       : (n,) integer labels
        feature_names : p feature names (used in GPT-4.1 prompt)
        descriptions  : p feature descriptions (block i of the prompt)
        domain_tags   : p lists of ontology-aligned domain tags (block iii)
        """
        p = X_train.shape[1]

        # Step 1: Compute traditional scores and per-feature statistics
        mi, pearson, chi2_vals, var = compute_traditional_scores(
            X_train, y_train, random_state=self.random_state
        )
        T = aggregate_traditional_score(mi, pearson, chi2_vals, var)

        # Step 2: Compute semantic scores via GPT-4.1
        S = compute_semantic_scores(
            feature_names=feature_names,
            descriptions=descriptions,
            mutual_info=mi,
            pearson_r=pearson,
            chi2=chi2_vals,
            variance=var,
            domain_tags=domain_tags,
            api_key=self.api_key,
        )

        # Step 3: Greedy sequential selection with redundancy penalty
        selected: list[int] = []
        remaining = list(range(p))
        raw_scores = np.zeros(p)

        while remaining:
            R = compute_all_redundancy_penalties(X_train, selected, remaining)
            # Compute I for each candidate
            I_vals = (
                self.alpha * S[remaining]
                + self.beta * T[remaining]
                - self.gamma * R
            )
            best_local = int(np.argmax(I_vals))
            best_global = remaining[best_local]
            raw_scores[best_global] = I_vals[best_local]
            selected.append(best_global)
            remaining.remove(best_global)

        # Step 4: Select k via cross-validation
        k = self._select_k(X_train, y_train, selected)

        self.selected_indices_ = selected[:k]
        self.scores_ = raw_scores
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Return X reduced to the selected feature columns."""
        if self.selected_indices_ is None:
            raise RuntimeError("Call fit() before transform().")
        return X[:, self.selected_indices_]

    def fit_transform(self, X_train, y_train, feature_names, descriptions, domain_tags):
        return self.fit(X_train, y_train, feature_names, descriptions, domain_tags).transform(X_train)

    # ── Private helpers ────────────────────────────────────────────────────

    def _select_k(
        self,
        X: np.ndarray,
        y: np.ndarray,
        ordered_indices: list[int],
    ) -> int:
        """
        Choose k by 5-fold cross-validation: evaluate a Random Forest on
        subsets of size 1, 2, ... up to min(p, 200) and return the k that
        maximises mean CV accuracy.
        """
        p = len(ordered_indices)
        best_k, best_score = 1, -np.inf
        probe_values = list(range(1, min(p + 1, 201)))

        clf = RandomForestClassifier(
            n_estimators=100,
            random_state=self.random_state,
            n_jobs=-1,
        )
        for k in probe_values:
            subset = X[:, ordered_indices[:k]]
            score = cross_val_score(
                clf, subset, y,
                cv=StratifiedKFold(
                    n_splits=self.cv_folds,
                    shuffle=True,
                    random_state=self.random_state,
                ),
                scoring="accuracy",
            ).mean()
            if score > best_score:
                best_score = score
                best_k = k

        return best_k
